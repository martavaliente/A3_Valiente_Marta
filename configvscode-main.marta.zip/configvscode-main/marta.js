function Bye(){
      console.log ("Good Bye")
  }
  setTimeout(Bye, 10000);
